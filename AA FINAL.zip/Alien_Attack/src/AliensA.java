import processing.core.PApplet;
import processing.core.PImage;

public class AliensA {

	// variables
	public int x, y;
	private boolean move;
	public int velocidad;

	// Alien
	private PImage ALIENA;

	public AliensA(PApplet app, int x, int y, int velocidad) {
		ALIENA = app.loadImage("data/ALIEN AZUL.png");

		this.x = x;
		this.y = y;
		this.velocidad =velocidad ;
		move = true;
	}

	
	public void pintarAzul(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(ALIENA, x, y);
		app.imageMode(app.CORNER);
	}
	
	public void mover() {

		if (move) {
			y += velocidad;
		}

		}


	public int getY() {
		return y;
	}


	public void setY(int y) {
		this.y = y;
	}
	
	


	public int getX() {
		return x;
	}


	public void setX(int x) {
		this.x = x;
	}


	public boolean isMove() {
		return move;
	}


	public void setMove(boolean move) {
		this.move = move;
	}


	public int getVelocidad() {
		return velocidad;
	}


	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}


	public PImage getALIENA() {
		return ALIENA;
	}


	public void setALIENA(PImage aLIENA) {
		ALIENA = aLIENA;
	}

	
}
